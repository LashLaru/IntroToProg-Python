#-----------------------------------#
#Title: A Home Invotory script but with a TUPLE.
#By Jeff Laru.
#Date: Feb 10th 2019
#ChangeLogs: (Who,When,What)
#This script let a user read a To Do file and be able add/remove and TASKS and PRIORITIES of the list.  In addion
#the user will be able to save the updated To Do list as a file.
#-----------------------------------#


#When the program starts, load each row of data from the ToDo.txt text file into a Python dictionary.
#(The data will be stored like a row in a table.)


input("\nThis program will load a already created To Do list\nPress ENTER to view the list!\n")
f = open("toDo.txt","r") #opens file with name of to do texttile
row1 = f.readline().split(",") # splitting up the row
row2 = f.readline().split(",")
dict1 = {"TASK:":row1[0], "PRIORITY":row1[1]} # creating the first dictionary
dict2 = {"TASK:":row2[0], "PRIORITY":row2[1]} # creating the 2nd dictionary.
dictTable = [dict1,dict2] # creating a list of the above dictionaries.

#print out the current list for the file.
print('-' * 40)
for line in dictTable:
    print(str(line))
print('-' * 40)

# Giving the user and option tree to pick from.
while(True):
    print ("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
    print()#adding a new line

    # Step 3 -Show the current items in the table
    if (strChoice.strip() == '1'):
        print('-' * 40)
        for line in dictTable:
            print(str(line))
        print('_' * 40)
        continue
    # Step 4 - Add a new item to the list/Table
    elif(strChoice.strip() == '2'):
        moreTask = input(str("\nNew TASK to do: ")) # adding more TASKS to the TO DO list
        morePri = input(str("\nThe PRIORITY of it: "))  # adding PRIORITIES to the TO DO list
        dict3 = {"TASK:":moreTask, "PRIORITY":morePri}
        dictTable.append(dict3) # appending to the already created list.
    # Step 5 - Remove a new item to the list/Table
    elif(strChoice == '3'):
        input("You are about to remove the last ITEM on the To Do list\nPress ENTER to do so!")
        dictTable.pop()
        continue
    # Step 6 - Save tasks to the ToDoNew.txt file
    elif(strChoice == '4'):
        f = open("toDoNew.txt", "w")
        f.write(str('-' * 40) + "\n")
        for row in dictTable:
            print(row)
            f.write(str(row).strip("{").strip("}").strip("\n") + "\n")
        f.write(str('-' * 40) + "\n")
        f.close()
        continue
    elif (strChoice == '5'):
        break #and Exit the program