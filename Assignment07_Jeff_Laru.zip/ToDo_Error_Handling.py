#-------------------------------------------------#
# Title: Exception Handling
# Dev:   Jeff Laru
# Date:  Feb 23, 2019
# ChangeLog: (Who, When, What)
# Script originally written by R. Randel, but edited and changed by Jeff Laru to include Classes and Functions(Methods).
# Assignment 07
#-------------------------------------------------#


#Global Variables
objFileName = "Todo1.txt"
strData = ""
dicRow = {}
lstTable = []

# When the program starts, load the any data you have in a text file called ToDo.txt into a python Dictionary.

# Made a class to handle the Reading and the Writing of the ToDo.txt file
try:
    class ReadWriteFile(object):
        '''This class Reads and Writes user data to a text file called ToDo.txt'''

        @staticmethod
        #Read the data from the ToDo.txt file and parse it out
        def ReadFileData(FileName):
            objFile = open(FileName, "r")
            for line in objFile:
                lstData = line.split(",") # readline() reads a line of the data into 2 elements
                dicRow = {"Task":lstData[0].strip(), "Priority":lstData[1].strip()}
                lstTable.append(dicRow)
                objFile.close()
                return lstTable
        @staticmethod
        def SaveToFile():
            # Show the current items in the table
            DisplayData.ShowCurrentTasks(lstTable)
            #  Ask if they want save that data
            if ("y" == str(input("Save this data to file? (y/n) - ")).strip().lower()):
                objFile = open(objFileName, "w")
                for dicRow in lstTable:
                    objFile.write(dicRow["Task"] + "," + dicRow["Priority"] + "\n")
                    objFile.close()
                    input("Data saved to file! Press the [Enter] key to return to menu.")
            else:
                input("New data was NOT Saved, but previous data still exists! Press the [Enter] key to return to menu.")



# Made another class just to handle the display / print output.
    class DisplayData(object):
        '''This Class is for displaying the Data to the user'''
        @staticmethod
        def ShowCurrentTasks(lstTable):
            print("\n******* The current items ToDo are: *******")
            for row in lstTable:
                print(row["Task"] + "(" + row["Priority"] + ")")
            print("*******************************************")
        def ShowCurrentTable():
            print("\nCurrent Data in table:")
            for dicRow in lstTable:
                print(dicRow)
        def MenuOptions():
            # # Display a menu of choices to the user
            while (True):
                print("""
Menu of Options
1) Show current data
2) Add a new item.
3) Remove an existing item.
4) Save Data to File
5) Exit Program
            """)
                strChoice = str(input("Which option would you like to perform? [1 to 5] - "))
                print()

                # Show the current items in the table
                if (strChoice.strip() == '1'):
                    DisplayData.ShowCurrentTasks(lstTable)

                # Add a new item to the list/Table
                elif (strChoice.strip() == '2'):
                    AddRemoveTask.AddNewTask()

                # Remove a new item to the list/Table
                elif (strChoice == '3'):
                    AddRemoveTask.RemoveTask()

                # Save tasks to the ToDo.txt file
                elif (strChoice == '4'):
                    ReadWriteFile.SaveToFile()

                # Exit the program
                elif (strChoice == '5'):
                    print("Have a nice day")
                    break

    # My last class is just to handle the ADD / REMOVE of tasks to the list.
    class AddRemoveTask(object):
        '''This class will ADD and REMOVE tasks from the ToDo list'''
        @staticmethod
        def AddNewTask():
            # Allow user to add TASKS to the list.
            strTask = str(input("What is the task? - ")).strip()
            strPriority = str(input("What is the priority? [high|low] - ")).strip()
            dicRow = {"Task": strTask, "Priority": strPriority}
            lstTable.append(dicRow)
        # DisplayData.ShowCurrentTable()
            DisplayData.ShowCurrentTasks(lstTable)

        @staticmethod
        def RemoveTask():
            # -Allow user to indicate which row to delete
            strKeyToRemove = input("Which TASK would you like removed? - ")
            blnItemRemoved = False  # Creating a boolean Flag
            intRowNumber = 0
            while (intRowNumber < len(lstTable)):
                if (strKeyToRemove == str(
                    list(dict(lstTable[intRowNumber]).values())[0])):  # the values function creates a list!
                    del lstTable[intRowNumber]
                    blnItemRemoved = True
                # end if
                intRowNumber += 1
        # end for loop
        # Update user on the status
            if (blnItemRemoved == True):
                print("\nThe task " + strKeyToRemove.upper() + " was removed from the To Do list.\n")
                print("Your ToDo list now looks like:")
                DisplayData.ShowCurrentTasks(lstTable)
            else:
                print("I'm sorry, but I could not find that task.")
            #  Show the current items on the ToDo List.
                DisplayData.ShowCurrentTasks(lstTable)

    lstTable = ReadWriteFile.ReadFileData(objFileName)

    DisplayData.MenuOptions()


# I put in a simple TRY and Expect around all the classed to make sure there was a TODO file to read from.
except FileNotFoundError as e:
    print("The To Do list does not exist.", "---->",objFileName)
